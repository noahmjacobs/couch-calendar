# Couch Calendar — iOS redesign

Everything from the design, as working React. Three files replace three files.
No new dependencies, no build changes, Firebase untouched.

---

## 1. Install

Copy over your existing files:

    react-port/src/App.jsx    ->  src/App.jsx
    react-port/src/App.css    ->  src/App.css
    react-port/src/style.css  ->  src/style.css

Then:

    npm run dev

Open it on your phone (same wifi) at the Network URL Vite prints — the design is
built phone-first, so that's where it looks right.

Push it:

    git add src/App.jsx src/App.css src/style.css
    git commit -m "iOS redesign: tabs, glass, dark mode, settings"
    git push

---

## 2. What you get

**Splash** — "449 Boyos" gradient wordmark, roommate dots, #Nodurfing, loading
bar. 1.5s then fades.

**Calendar tab**

- *Day* — free stretches collapse into one tappable row ("4 PM – 7 PM · Free")
  instead of 24 empty cells. Bookings are cards tinted with the owner's colour.
- *Week* — a strip of seven day pills, then that week's bookings grouped by day.
  The old 7×24 grid is gone; it never worked at phone width.
- *Month* — grid with a colour dot per booking, tap a day to see its list below.
- Empty state when a day is free, skeleton cards while Firebase loads.

**Roommates tab** — monthly date leaderboard (ranked, leader tinted pink) and an
all-time list per roommate.

**Settings tab** — your name, partner's name, reservation style, appearance.

**Reservation sheet** — full-screen, opens from the Reserve button.

---

## 3. The two reservation flows

Both are built. Switch between them in **Settings → Reserving**. The choice is
saved in `localStorage` under `couch.flow`.

### Time bar (default, `flow = 'bar'`)

A 24-hour track. Drag the blue block to move it, pull either end to resize.
Other people's bookings show as tinted blocks in the track, and the drag stops
dead at them — you physically cannot create an overlap.

Best when you're picking a slot around what's already booked. Fastest for the
common case. Harder to hit an exact hour with a thumb.

### Wheel (`flow = 'wheel'`)

Two iOS-style scrolling columns, Starts and Ends. Scroll or tap to a value; it
snaps. Hours already taken never appear in the Starts column, and the Ends
column stops at the next booking.

Best when you know the exact time you want. Slower to scan the day.

**My recommendation: ship the time bar.** Roommates booking a couch are almost
always answering "when is it free tonight", not "I need 7:00 sharp", and the bar
answers that in one gesture. Keep the wheel in Settings for the people who hate
dragging. If you want only one, delete the other branch in `renderSheet()` and
drop its component — they're independent.

---

## 4. What did not change

- Firebase wiring: same `db` import, same `onValue` / `set` / `remove`.
- Data path and shape: `reservations/{YYYY-MM-DD}/{startHour}` holding
  `{ name, type, details, guestName, hour, endHour, timestamp }`.
- The overlap rule, the 24-hour day, the roommate list.

Existing reservations load and display as they are. Nothing to migrate.

---

## 5. What's new in behaviour

**You pick your name once.** Settings → Your name. Stored in `localStorage`
(`couch.me`). Reservations no longer ask who you are. Tapping Reserve with no
name set drops you on Settings.

**Partner autofill.** Set a partner in Settings; choosing Date prefills their
name with an "Autofilled" tag. Still editable — type someone else and the tag
disappears. No partner set, no prefill.

**Privacy.** Other people's bookings show name, time and type only. Details
appear when you tap. Yours always show, and tapping reveals Delete.

**No emoji.** Roommate colour is the identity. A grey dot means Event, pink
means Date. That's the whole legend.

**Dark mode.** Follows the phone via `prefers-color-scheme`. Settings →
Appearance overrides it with Light / Dark / Automatic, stored in `couch.theme`.
It works by setting `data-theme` on `<html>`; every colour in `App.css` is a CSS
variable defined for both.

---

## 6. Changing things

**Roommates and colours** — top of `App.jsx`:

    const ROOMMATES = [
      { name: 'Noah', color: '#0A84FF', ink: '#fff' },
      ...
    ]

`ink` is the text colour of the avatar circle. Keep it readable: white on the
blue/purple/pink, dark on the green/orange.

**Splash timing** — the `useEffect` near the top of `App`. `1500` is how long it
holds, `2000` is when it unmounts; the 500ms gap is the fade.

**Accent colour** — `--accent` in `App.css`, two places (light block and dark
block).

**Glass strength** — `--glass`, `--glass-border` and `--blur`. More blur is
heavier on old phones; 30px is a safe ceiling.

**Splash text** — the `Splash` component, plain strings.

---

## 7. Notes and gotchas

- `.res-card` tints with `color-mix()`: Safari 16.4+, Chrome 111+. On anything
  older the card falls back to plain glass — still fine, just less colourful.
- The layout caps at 560px and centres, so a desktop browser gets the phone
  layout in the middle of the window rather than a stretched mess.
- Everything tappable is at least 44px tall, which is Apple's minimum. If you
  add buttons, hold that line.
- The tab bar and Reserve button are `position: fixed` with
  `env(safe-area-inset-bottom)`, so they sit above the home indicator on a real
  iPhone.
- Firebase security rules are unchanged and still wide open per your README. If
  this ever leaves your apartment, lock them down.

# Couch Calendar — iOS redesign port

Drop-in replacement for three files. Nothing else in your project changes.

## Install

Copy these over your existing files:

    react-port/src/App.jsx    ->  src/App.jsx
    react-port/src/App.css    ->  src/App.css
    react-port/src/style.css  ->  src/style.css

Then `npm run dev`. No new dependencies.

## What stayed the same

- Firebase Realtime Database wiring is untouched: same `db` import, same
  `onValue` / `set` / `remove` calls.
- Same data path and shape: `reservations/{YYYY-MM-DD}/{startHour}` with
  `{ name, type, details, guestName, hour, endHour, timestamp }`.
- Same overlap rule, same 24-hour day, same roommate list.
  Existing reservations show up as they are.

## What's new

- **Three tabs**: Calendar, Roommates, Settings.
- **Settings** stores your name, your partner's name, and Light/Dark/Automatic
  in `localStorage` (`couch.me`, `couch.partner`, `couch.theme`). You pick your
  name once — reservations no longer ask "who are you".
- **Partner autofill**: with a partner saved, picking Date prefills their name.
  The field stays editable and shows an "Autofilled" tag.
- **Day view** collapses free stretches into one tappable row instead of 24
  empty cells.
- **Week view** is a day-pill strip plus a grouped list — the 7x24 grid is gone
  on phone widths.
- **Month view** shows colour dots per day and a list for the selected day.
- **Privacy**: other people's blocks show name, time and type. Details appear on
  tap. Your own always show, and reveal a Delete button.
- **No emoji.** Roommate colour is the identity; a grey dot means Event, pink
  means Date.
- **Dark mode** follows the phone via `prefers-color-scheme`, overridden by the
  Settings toggle (`data-theme` on `<html>`).

## Notes

- Roommate colours live at the top of `App.jsx` in `ROOMMATES`. Add or rename
  people there.
- The layout is capped at 560px and centred, so it also looks right in a desktop
  browser window.
- `.res-card` uses `color-mix()` for the roommate tint (Safari 16.4+, Chrome
  111+). If you need older support, swap it for a flat `var(--glass)`.
